𝙒𝙆𝙒𝙆𝙆𝙒 𝙈𝘼𝙐 𝘿𝙄 𝙍𝙀𝙉𝘼𝙈𝙀 𝙂𝘼 𝙏𝙐𝙃
𝘾𝙍𝙀𝘼𝙏𝙊𝙍 𝙎𝘾𝙍𝙄𝙋𝙏 = @𝗞𝗛𝗢𝗦𝗔-𝗕𝗛
𝘽𝘼𝙎𝙀 𝙎𝘾𝙍𝙄𝙋𝙏 = 𝙎𝙆𝙔𝙕𝙊

case "kangrinem"
const textnya = `kang rinem tobatla dipikir ga cape apa recode sc mati matian